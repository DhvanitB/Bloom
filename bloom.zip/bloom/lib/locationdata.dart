import 'package:flutter/material.dart';
import 'data.dart';

class LocationData extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Hospitals"),
        centerTitle: true,
        backgroundColor: Color(0xFF4DB2E7)
      ),
      body: Center(
        child: Column(
          children: <Widget>[
            SizedBox(
              height: 150,
            ),
            InkWell(
              onTap: () {
                //Navigator.push(context, MaterialPageRoute (builder: (context) => Maps()));
              },
              child:  Container(
                width: 200,
                child: Center(child: Text('Hospital Location',style: TextStyle(color: Colors.greenAccent, fontSize: 17),)),
                color: Colors.blueAccent,
                padding: EdgeInsets.all(20.0),
              ),
            ),
            SizedBox(
              height: 35,
            ),
            InkWell(
              onTap: () {
                Navigator.push(context, MaterialPageRoute (builder: (context) => Data()));
              },
              child:  Container(
                width: 200,
                child: Center(child: Text('Hospital Data',style: TextStyle(color: Colors.greenAccent, fontSize: 16),)),        //data
                color: Colors.blueAccent,
                padding: EdgeInsets.all(20.0),
              ),
            ),
          ],
        ),
      ),

    );
  }
}
