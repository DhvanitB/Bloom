import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Data extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Hospitals"),
        centerTitle: true,
        backgroundColor: Color(0xFF4DB2E7),
        elevation: 0.0,
      ),
      body: ListView(
        children: [
          SizedBox(height: 15,),
          Container(
            height: 180,
            padding: EdgeInsets.all(10),
            child: Card(
              elevation: 5.0,
              color: Colors.blue[200],
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0)
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  const ListTile(
                    //leading: Icon(Icons.local_hospital, size: 70),
                    title:
                    Text('KJ Somaiya Hospital', style: TextStyle(fontSize: 20.0),),
                    subtitle:
                    Text('K J Somaiya Hospital and Research Center, Somaiya Ayurvihar Complex, Eastern Express Highway, Sion(E), Mumbai - 400 022'),
                  ),
                ],
              ),
            ),
          ),
          Container(
            height: 180,
            padding: EdgeInsets.all(10),
            child: Card(
              elevation: 5.0,
              color: Colors.blue[200],
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0)
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  const ListTile(
                    //leading: Icon(Icons.local_hospital, size: 70),
                    title:
                    Text('Nanavati Hospital', style: TextStyle(fontSize: 20.0),),
                    subtitle:
                    Text('Nanavati Super Speciality Hospital, S.V. Road, Mumbai, Maharashtra - 400056, Phone: 022 2626 7500'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
     );
    }
  }